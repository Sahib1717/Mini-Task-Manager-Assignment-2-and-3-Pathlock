
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { projectsAPI } from '../services/api';
import { Project } from '../types';
import { useAuth } from '../context/AuthContext';
import Header from '../components/Header'; // App title

const Dashboard: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newProjectTitle, setNewProjectTitle] = useState('');
  const [newProjectDescription, setNewProjectDescription] = useState('');

  const { logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      const response = await projectsAPI.getProjects();
      setProjects(response.data);
    } catch (err: any) {
      setError('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await projectsAPI.createProject({
        title: newProjectTitle,
        description: newProjectDescription,
      });
      setNewProjectTitle('');
      setNewProjectDescription('');
      setShowCreateForm(false);
      loadProjects();
    } catch (err: any) {
      setError('Failed to create project');
    }
  };

  const handleDeleteProject = async (id: number) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      try {
        await projectsAPI.deleteProject(id);
        loadProjects();
      } catch (err: any) {
        setError('Failed to delete project');
      }
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#e6f2ff', paddingBottom: '50px', fontFamily: 'Segoe UI, sans-serif' }}>
      <Header /> {/* App title */}

      <div
        style={{
          maxWidth: '800px',
          margin: '30px auto',
          padding: '30px',
          borderRadius: '12px',
          boxShadow: '0 8px 20px rgba(0,0,0,0.15)',
          background: 'linear-gradient(135deg, #f5f7fa, #c3cfe2)',
        }}
      >
        {/* Dashboard title + Logout */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h1>My Projects</h1>
          <button
            onClick={handleLogout}
            style={{
              padding: '8px 16px',
              backgroundColor: '#ff4444',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 600,
              transition: '0.3s',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#cc0000')}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#ff4444')}
          >
            Logout
          </button>
        </div>

        {error && (
          <div
            style={{
              color: '#ff4d4f',
              marginBottom: '15px',
              padding: '10px',
              borderRadius: '8px',
              backgroundColor: '#ffe6e6',
              textAlign: 'center',
            }}
          >
            {error}
          </div>
        )}

        <button
          onClick={() => setShowCreateForm(!showCreateForm)}
          style={{
            marginBottom: '20px',
            padding: '10px 16px',
            borderRadius: '8px',
            border: 'none',
            backgroundColor: '#4a90e2',
            color: 'white',
            fontWeight: 600,
            cursor: 'pointer',
            transition: '0.3s',
          }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#357ABD')}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#4a90e2')}
        >
          {showCreateForm ? 'Cancel' : 'Create New Project'}
        </button>

        {showCreateForm && (
          <form
            onSubmit={handleCreateProject}
            style={{ marginBottom: '20px', padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}
          >
            <h3>Create New Project</h3>
            <div style={{ marginBottom: '10px' }}>
              <label>Title:</label>
              <input
                type="text"
                value={newProjectTitle}
                onChange={(e) => setNewProjectTitle(e.target.value)}
                required
                minLength={3}
                maxLength={100}
                style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ccc' }}
              />
            </div>
            <div style={{ marginBottom: '10px' }}>
              <label>Description:</label>
              <textarea
                value={newProjectDescription}
                onChange={(e) => setNewProjectDescription(e.target.value)}
                maxLength={500}
                style={{ width: '100%', padding: '10px', minHeight: '100px', borderRadius: '6px', border: '1px solid #ccc' }}
              />
            </div>
            <button
              type="submit"
              style={{
                padding: '10px 20px',
                borderRadius: '6px',
                border: 'none',
                backgroundColor: '#4a90e2',
                color: 'white',
                fontWeight: 600,
                cursor: 'pointer',
                transition: '0.3s',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#357ABD')}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#4a90e2')}
            >
              Create Project
            </button>
          </form>
        )}

        <div>
          {projects.length === 0 ? (
            <p>No projects found. Create your first project!</p>
          ) : (
            projects.map((project) => (
              <div
                key={project.id}
                style={{
                  border: '1px solid #ccc',
                  padding: '15px',
                  marginBottom: '10px',
                  borderRadius: '8px',
                  backgroundColor: '#ffffff',
                  boxShadow: '0 4px 8px rgba(0,0,0,0.05)',
                }}
              >
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <p style={{ color: '#555' }}>Created: {new Date(project.creationDate).toLocaleDateString()}</p>
                <p style={{ color: '#555' }}>Tasks: {project.tasks.length}</p>
                <div>
                  <Link to={`/project/${project.id}`} style={{ marginRight: '10px' }}>
                    <button
                      style={{
                        padding: '6px 12px',
                        cursor: 'pointer',
                        borderRadius: '6px',
                        border: 'none',
                        backgroundColor: '#4a90e2',
                        color: 'white',
                        fontWeight: 600,
                        transition: '0.3s',
                      }}
                      onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#357ABD')}
                      onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#4a90e2')}
                    >
                      View Details
                    </button>
                  </Link>
                  <button
                    onClick={() => handleDeleteProject(project.id)}
                    style={{
                      backgroundColor: '#ff4444',
                      color: 'white',
                      padding: '6px 12px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      border: 'none',
                      transition: '0.3s',
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#cc0000')}
                    onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#ff4444')}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
